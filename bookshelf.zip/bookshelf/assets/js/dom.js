const UNREAD_BOOKSHELF_ID = "unread";
const READ_BOOKSHELF_ID = "read";
const BOOKSHELF_BOOKID = "bookId";

function addBook() {
    const unreadBookshelf = document.getElementById(UNREAD_BOOKSHELF_ID);

    const titleBook = document.getElementById("inputBookTitle").value;
    const authorBook = document.getElementById("inputBookAuthor").value;
    const yearBook = document.getElementById("inputBookYear").value;

    const bookshelf = makeBookshelf(titleBook, authorBook, yearBook, false);
    const bookshelfObject = composeBookshelfObject(titleBook, authorBook, yearBook, false);
    
    bookshelf[BOOKSHELF_BOOKID] = bookshelfObject.id;
    bookshelfs.push(bookshelfObject);
    
    unreadBookshelf.append(bookshelf);
    updateDataToStorage();

}

function makeBookshelf(title, author, year, isRead) {
    const textTitle = document.createElement("h3");
    textTitle.innerText = title;

    const textAuthor = document.createElement("p");
    textAuthor.innerText = author;

    const textYear = document.createElement("span");
    textYear.innerText = year;

    const textContainer = document.createElement("div");
    textContainer.classList.add("book-detail");
    textContainer.append(textTitle, textAuthor, textYear);

    const container = document.createElement("div");
    container.classList.add("book-item");
    container.append(textContainer);

    if (isRead) {
        container.append(
            createUndoButton(),
            createDeleteButton()
        );
    } else {
        container.append(
            createReadButton(),
            createDeleteButton()
            );
    }

    return container;
}

function createButton(buttonTypeClass, eventListener) {
    const button = document.createElement("button");
    button.classList.add(buttonTypeClass);
    button.addEventListener("click", function (event) {
        eventListener(event);
    });
    return button;
}

function addBookRead(readElement) {
    const readBookshelf = document.getElementById(READ_BOOKSHELF_ID);
    const readTitle = readElement.querySelector(".book-detail > h3").innerText;
    const readAuthor = readElement.querySelector(".book-detail > p").innerText;
    const readYear = readElement.querySelector(".book-detail > span").innerText;

    const newBookshelf = makeBookshelf(readTitle, readAuthor, readYear, true);
    const bookshelf = findBookshelf(readElement[BOOKSHELF_BOOKID]);
    bookshelf.isRead = true;
    newBookshelf[BOOKSHELF_BOOKID] = bookshelf.id;

    readBookshelf.append(newBookshelf);
    readElement.remove();

    updateDataToStorage();
}

function createReadButton() {
    return createButton("btn-read", function (event) {
        addBookRead(event.target.parentElement);
    });
}

function removeBookFromRead(readElement) {
    const bookshelfPosition = findBookshelfIndex(readElement[BOOKSHELF_BOOKID]);
    bookshelfs.splice(bookshelfPosition, 1);

    readElement.remove();
    updateDataToStorage();
}

function createDeleteButton() {
    return createButton("btn-delete", function (event) {
        removeBookFromRead(event.target.parentElement);
    });
}

function undoBookRead(readElement) {
    const bookUnread = document.getElementById(UNREAD_BOOKSHELF_ID);
    const readTitle = readElement.querySelector(".book-detail > h3").innerText;
    const readAuthor = readElement.querySelector(".book-detail > p").innerText;
    const readYear = readElement.querySelector(".book-detail > span").innerText;

    
    const newBookshelf = makeBookshelf(readTitle, readAuthor, readYear, false);

    const bookshelf = findBookshelf(readElement[BOOKSHELF_BOOKID]);
    bookshelf.isRead = false;
    newBookshelf[BOOKSHELF_BOOKID] = bookshelf.id;

    bookUnread.append(newBookshelf);
    readElement.remove();

    updateDataToStorage();
}

function createUndoButton() {
    return createButton("btn-undo", function (event) {
        undoBookRead(event.target.parentElement);
    });
}